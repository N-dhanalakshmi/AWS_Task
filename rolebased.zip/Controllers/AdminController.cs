using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using rolebased.Models;
using System.Security.Claims;

namespace rolebased.Controllers;

    public class AdminController:Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(Login login)
        {
            if((string.IsNullOrEmpty(login.username))&&(string.IsNullOrEmpty(login.password)))
            {
              return RedirectToAction("Login");
            }
            ClaimsIdentity? identity=null;
            bool isAuthenticate=false;
            if(login.username=="dhana"&&login.password=="dhana"){
                identity=new ClaimsIdentity (new[]
                {
                    new Claim(ClaimTypes.Name,login.username),
                    new Claim(ClaimTypes.Role,"admin"),
                    
                },CookieAuthenticationDefaults.AuthenticationScheme);
                isAuthenticate=true;
            }
            if(login.username=="neela"&&login.password=="neela"){
                identity=new ClaimsIdentity (new[]
                {
                    new Claim(ClaimTypes.Name,login.username),
                    new Claim(ClaimTypes.Role,"user"),
                    
                },CookieAuthenticationDefaults.AuthenticationScheme);
                isAuthenticate=true;
            }
            if(isAuthenticate==true)
            {
                
                return RedirectToAction("Index","Home");
            }

            return View();
        }

    }
